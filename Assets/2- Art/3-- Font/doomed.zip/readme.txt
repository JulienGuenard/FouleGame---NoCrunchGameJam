This font "Doomed" is created by Jack Oatley.
Co-member of Bitty/Brixdee on http://www.dafont.com/profile.php?user=764521

It is 100% free to use, though credit is appreciated and it'd be cool to know where you used it. You must not claim it as your own.

Image by Andrzej Rembowski from Pixabay
